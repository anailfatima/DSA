#include "myLL.h"

int main()
{
	myLL obj;

	obj.insertAtTail(40);
	obj.insertAtTail(10);
	obj.insertAtTail(30);
	obj.insertAtTail(10);
	obj.insertAtTail(10);
	obj.insertAtTail(25);

	obj.sortTheUnsorted();

	cout << "Display: " << endl;

	obj.display();

	return 0;
}